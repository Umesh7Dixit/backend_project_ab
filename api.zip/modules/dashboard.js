class dashboard {
    constructor(_utility) {
        this.utility = _utility;
    }
        
}
module.exports = dashboard;