class Facilities {
  constructor(utility) {
    this.utility = utility;

    this.searchFacilitiesByUser = this.searchFacilitiesByUser.bind(this);
  }
  async searchFacilitiesByUser(req, res) {
    try {
      const isGet = req.method === 'GET';
      const userId = isGet ? parseInt(req.query.user_id, 10) : parseInt(req.body.user_id, 10);
      const searchTerm = isGet ? (req.query.search_term || '').trim() : (req.body.search_term || '').trim();

      if (!Number.isInteger(userId)) {
        return this.utility.response.init(res, false, "Invalid or missing 'user_id'.");
      }
      if (!searchTerm) {
        return this.utility.response.init(res, false, "Invalid or missing 'search_term'.");
      }

      const query = {
        text: 'SELECT * FROM public.search_facilities_by_user($1, $2);',
        values: [userId, searchTerm],
      };

      const result = await this.utility.sql.query(query);

      return this.utility.response.init(
        res,
        true,
        "Facilities fetched successfully",
        { rows: result.rows }
      );
    } catch (err) {
      console.error("searchFacilitiesByUser error:", err);
      return this.utility.response.init(res, false, "Internal server error");
    }
  }

  GetAccessibleFacilities = async (req, res) => {
    try {
      const { search_term } = req.query;
      const user_id = req.user.userId; // Get from JWT token
      console.log("search_term ", search_term);
      console.log("user_id ", user_id);

      const query = {
        text: 'SELECT * FROM get_accessible_facilities_for_user($1, $2)',
        values: [user_id, search_term || '']
      };

      const result = await this.utility.sql.query(query);
      
      if (!result.rows) {
        return this.utility.response.init(res, false, "No response from database", {
          error: "DATABASE_ERROR"
        }, 500);
      }

      return this.utility.response.init(
        res,
        true,
        "Facilities fetched successfully",
        { 
          facilities: result.rows,
          count: result.rows.length
        }
      );

    } catch (error) {
      console.error('Error fetching accessible facilities:', error);
      return this.utility.response.init(
        res, 
        false, 
        "Internal server error while fetching facilities", 
        {
          error: "INTERNAL_SERVER_ERROR",
          details: error.message
        }, 
        500
      );
    }
  };
}

module.exports = Facilities;